library(Matrix) # Use sparse matrix capability in R

# Randomly generate test data for 
# p=1000 individuals, where each individual selects 50 opponents
# (NB: Every individual will actually have more than 50 opponents
# because of being selected by others. On average, each individual will
# have 100 opponents.)
set.seed(123)
p <- 1000
gamma0 <- (1:p) + p/10
gamma0 <- gamma0/sum(gamma0)

games <- 50
W <- Matrix(0, p, p) # Use sparse matrix representation
for(i in 1:p) {
	opponents <- sample((1:p)[-i], games)
	results <- runif(games) < (gamma0[i]/(gamma0[i]+gamma0[opponents]))
	wins <- opponents[results]
	losses <- opponents[!results]
	W[i,wins] <- W[i,wins]+1
	W[losses,i] <- W[losses,i]+1
}
Wsmall <- W

# Now repeat the process for a larger dataset
# p=2000 individuals, each individual selects 100 opponents
# (NB: Every individual will actually have more than 100 opponents
# because of being selected by others. On average, each individual will
# have 200 opponents.)
set.seed(456)
p <- 2000
gamma0 <- (1:p) + p/10
gamma0 <- gamma0/sum(gamma0)

games <- 100
W <- Matrix(0, p, p) # Use sparse matrix representation
for(i in 1:p) {
	opponents <- sample((1:p)[-i], games)
	results <- runif(games) < (gamma0[i]/(gamma0[i]+gamma0[opponents]))
	wins <- opponents[results]
	losses <- opponents[!results]
	W[i,wins] <- W[i,wins]+1
	W[losses,i] <- W[losses,i]+1
}


