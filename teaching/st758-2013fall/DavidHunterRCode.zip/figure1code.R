# Generate test data
source("testData.R")

# source in the relevant functions
source("newtonBradleyTerry.R")
source("mmBradleyTerry.R")

# Results for p=2000 problem:
unix.time(NR<-NewtonBradleyTerry(W)) # Find final parameter value
unix.time(NR<-NewtonBradleyTerry(W, finalGamma=NR$final))
NR0 <- sqrt(sum((rep(1,1000)/1000-NR$final)^2))

unix.time(MM<-MMBradleyTerry(W)) # Find final parameter value
unix.time(MM<-MMBradleyTerry(W, finalGamma=MM$final))
MM0 <- sqrt(sum((rep(1,1000)/1000-MM$final)^2))

# Results for p=1000 problem:
unix.time(NR2<-NewtonBradleyTerry(Wsmall)) # Find final parameter value
unix.time(NR2<-NewtonBradleyTerry(Wsmall, finalGamma=NR2$final))
NR02 <- sqrt(sum((rep(1,1000)/1000-NR2$final)^2))

unix.time(MM2<-MMBradleyTerry(Wsmall)) # Find final parameter value
unix.time(MM2<-MMBradleyTerry(Wsmall, finalGamma=MM2$final))
MM02 <- sqrt(sum((rep(1,1000)/1000-MM2$final)^2))

# Create plot(s)
a <- length(NR$norms) - 1
plot((0:a)*median(NR$iter[,3]), c(NR0,NR$norm[1:a]), log="y",
	pch=21,
	type="b", xlab="Time (seconds)", 
	ylab="Euclidean Norm of Error Vector",
	main="Algorithm convergence by time and iteration", cex.lab=1.3, 
	cex.axis=1.3, cex.main=1.5)
b <- length(MM$norms) - 1
points((0:(b/5))*5*median(MM$iter[,3]), c(MM0,MM$norm[5*(1:(b/5))]), 
	pch=20, type="b")
abline(h=1e-10, lty=2)

a2 <- length(NR2$norms) - 1
points((0:a2)*median(NR2$iter[,3]), c(NR02,NR2$norm[1:a2]), 
	pch=22, type="b")
b2 <- length(MM2$norms) - 1
points((0:(b2/5))*5*median(MM2$iter[,3]), c(MM02,MM2$norm[5*(1:(b2/5))]), 
	pch=15, type="b")

legend("topright", legend=c("1 NM iteration, p=1000", 
	"1 NM iteration, p=2000", "5 MM iterations, p=1000", 
	"5 MM iterations, p=2000"), cex=1.3, pch=c(22, 21, 15, 20), bty="n")

