#include <iostream>
#include <iomanip>
#include "pet.h"

using namespace std;

void abort(std::string msg) {
  std::cerr << msg << "\nAborting..." << std::endl;
  std::exit(1);
}

void helpMessage() {
  std::cerr << "Usage:\n\n";
  std::cerr << "petmain [--help] [--datafiles <string1> <string2>] [--maxiters <integer>] [--GPU <integer>] [--chngtol <double>] [--nsecant <integer>]\n\n";
  std::cerr << "If --help is specified, this usage message is shown\n\n";
  std::cerr << "If --datafiles is specified, the files containing C matrix and y vector \n";
  std::cerr << "   should be given\"\n";
  std::cerr << "   Default: ../../datasets/pet-126-by-256-C.txt ../../datasets/pet-126-by-256-y.txt\n\n";
  std::cerr << "If --penalty is specified, smooth image is recovered by penalizing roughness\n";
  std::cerr << "   Default: 0 \n\n";
  std::cerr << "If --GPU is specified, estimation proceeds on the GPU with given device number\n";
  std::cerr << "   Default: no GPU used \n\n";
  std::cerr << "If --chgtol is sepcified, algorithmic iteration stops when \n";
  std::cerr << "   the relative change of objective function is less than chgtol \n";
  std::cerr << "   Default: 1E-9 \n\n";
  std::cerr << "If --maxiters is specified, estimation terminates after the given number\n";
  std::cerr << "   of iterations if convergence has not occurred\n";
  std::cerr << "   Default: 100000 \n\n";
  std::cerr << "If --nsecant is sepcified, quasi-Newton acceleration is invoked. \n";
  std::cerr << "   High performance is typically achieved by setting nsecant to 5-15.\n";
  std::cerr << "   Default: 0 (no acceleration)\n\n";
  std::cerr << "Example usages: \n\n";
  std::cerr << "./petmain --help\n";
  std::cerr << "./petmain --datafiles ./pet-126-by-256-C.txt ./pet-126-by-256-y.txt --penalty 0 \n";
  std::cerr << "./petmain --datafiles ./pet-126-by-256-C.txt ./pet-126-by-256-y.txt --penalty 1e-6 --nsecant 5 \n";
  std::cerr << "./petmain --datafiles ./pet-126-by-256-C.txt ./pet-126-by-256-y.txt --penalty 0 --chgtol 0 --maxiters 2000 \n";
  std::cerr << "./petmain --datafiles ./pet-126-by-256-C.txt ./pet-126-by-256-y.txt --penalty 1e-6 --maxiters 2000 --GPU 0 \n";
  std::exit(0);
}

void interpretCommandLineParameters(int argc, const char* argv[],
				    string* fileNameC,
				    string* fileNameY,
				    double* penalty,
				    int* gpuDeviceNumber,
				    double* chgTol,
				    int* maxIters,
				    int* nSecants,
                                    long* flags)	{
  bool expecting_algorithm = false;
  bool expecting_fileNameC = false;
  bool expecting_fileNameY = false;
  bool expecting_gpuDeviceNumber = false;
  bool expecting_maxIters = false;
  bool expecting_penalty = false;
  bool expecting_nSecants = false;
  bool expecting_chgTol = false;

  *fileNameC = "./pet-126-by-256-C.txt";
  *fileNameY = "./pet-126-by-256-y.txt";
  *flags = 0;
  *penalty = 0;
  *gpuDeviceNumber = 0;
  *maxIters = 100000;
  *chgTol = 1e-9;
  *nSecants = 0;

  for (unsigned i = 1; i < argc; ++i) {
    std::string option = argv[i];

    if (expecting_fileNameC) {
      *fileNameC = option.c_str();
      expecting_fileNameC = false;
      expecting_fileNameY = true;
    } else if (expecting_fileNameY) {
      *fileNameY = option.c_str();
      expecting_fileNameY = false;
    } else if (expecting_penalty) {
      *penalty = atof(option.c_str());
      expecting_penalty = false;
    } else if (expecting_gpuDeviceNumber) {
      *gpuDeviceNumber = (unsigned)atoi(option.c_str());
      *flags |= GPU;
      expecting_gpuDeviceNumber = false;
    } else if (expecting_chgTol) {
      *chgTol = atof(option.c_str());
      expecting_chgTol = false;
    } else if (expecting_maxIters) {
      *maxIters = (unsigned)atoi(option.c_str());
      expecting_maxIters = false;
    } else if (expecting_nSecants) {
      *nSecants = (unsigned)atoi(option.c_str());
      expecting_nSecants = false;
    } else if (option == "--help") {
      helpMessage();
    } else if (option == "--algorithm") {
      expecting_algorithm = true;
    } else if (option == "--penalty") {
      expecting_penalty = true;
    } else if (option == "--datafiles") {
      expecting_fileNameC = true;
    } else if (option == "--GPU") {
      expecting_gpuDeviceNumber = true;
    } else if (option == "--maxiters") {
      expecting_maxIters = true;
    } else if (option == "--nsecant") {
      expecting_nSecants = true;
    } else if (option == "--chgtol") {
      expecting_chgTol = true;
    } else {
      std::string msg("Unknown command line parameter \"");
      msg.append(option);
      abort(msg.c_str());
    }
  }

  if (expecting_fileNameC | expecting_fileNameY)
    abort("read last command line option without finding value associated with --datafile");

  if (expecting_algorithm)
    abort("read last command line option without finding value associated with --algorithm");

  if (expecting_penalty)
    abort("read last command line option without finding value associated with --penalty");

  if (expecting_gpuDeviceNumber)
    abort("read last command line option without finding value associated with --GPU");

  if (expecting_maxIters)
    abort("read last command line option without finding value associated with --maxIters");

  if (*maxIters <= 0)
    abort("invalid number of iterations supplied on the command line");

  if (*penalty < 0)
    abort("invalid penalty supplied on the command line");

  if (*nSecants < 0)
    abort("invalid nSecants supplied on the command line");

  if (*chgTol<0)
    abort("invalid chgTol supplied on the command line");

  if ( (*flags & GPU) && (*gpuDeviceNumber < 0) )
    abort("invalid GPU device number supplied on the command line");

  if (!(*flags & GPU))
    *flags |= CPU;
}


int main(int argc, const char* argv[])
{
  double penalty;
  long flags;
  string fileNameC;
  string fileNameY;
  int maxIters;
  int gpuDeviceNumber;
  int nSecants;
  double chgTol;

  interpretCommandLineParameters(argc, argv,
				 &fileNameC,
				 &fileNameY,
				 &penalty,
				 &gpuDeviceNumber,
				 &chgTol,
				 &maxIters,
				 &nSecants,
				 &flags);

  // Read in data and compute NNMF
  PET testmatrix (fileNameC.c_str(),fileNameY.c_str());
  testmatrix.SetAlgoParams (chgTol,maxIters,nSecants,gpuDeviceNumber);
  testmatrix.SolvePET (penalty,flags);
  // output the estimated image
  // testmatrix.OutputImage();

  // Output Results
  double *Pixs = testmatrix.GetPixels ();
  cout.precision (10);
  cout.setf (ios::left);
  cout << endl;
  cout << "# pixels = " << testmatrix.GetNpixels () << endl;
  cout << "# lines = " << testmatrix.GetNlines () << endl;
  cout << "Penalty = " << testmatrix.GetPenalty () << endl;
  cout << "Stopping criterion = " << testmatrix.GetChgtol () << endl << endl;
  cout << "Algorithm: \n" << testmatrix.GetAlgo () << endl << endl;
  cout << "Final Objective Value: " << endl;
  cout << setw(10) << testmatrix.GetObjval () << endl << endl;
  cout << "# Iterations:" << endl;
  cout << setw(8) << testmatrix.GetNiters () << endl << endl;
  cout << "Elapsed Time:" << endl;
  cout << setw(8) << testmatrix.GetAlgoTiming () << endl << endl;
  cout << "GPU Precision: " << ((sizeof(REAL) == 4) ? "Single" : "Double") << endl << endl;

  return 0;
}
