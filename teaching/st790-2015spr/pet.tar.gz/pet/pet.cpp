#include <time.h>
#include <sys/time.h>

#include <cuda_runtime_api.h>

#include "pet.h"

PET::PET (const char* infileC, const char* infileY) {

    // read in C matrix (L-by-P)
    ifstream inFile;
    cout << "\n\nRead in matrix C: " << infileC << endl;
    inFile.open (infileC);
    if (!inFile) {
        cerr << "Datafile " << infileC << " open failed!\n\n";
        exit(1);
    }
    // first line contains: L, P, imgNrows, imgNcols
    inFile >> L;
    inFile >> P;
    inFile >> imgNrows;
    inFile >> imgNcols;
    sizeC = L*P;
    np_L = L;
    np_P = P;
    np_sizeC = sizeC;
    hC = gsl_matrix_alloc (L,P);
    double elem;
    for (int i=0; i<L; i++)
        for (int j=0; j<P; j++) {
            inFile >> elem;
            gsl_matrix_set (hC,i,j,elem);
        }
    inFile.close();

    // read in Y vector (length P)
    imgfile = infileY;
    cout << "Read in tube readings y: " << infileY << endl << endl;
    inFile.open (infileY);
    if (!inFile) {
        cerr << "Datafile " << infileY << " open failed!\n\n";
        exit(1);
    }
    hy = gsl_vector_alloc (L);
    for (int i=0; i<L; i++) {
        inFile >> elem;
        gsl_vector_set (hy,i,elem);
    }
    inFile.close ();

    // scale C to have column norms 1
    scale_C (hC);

    // allocate memory and initilize hpixels
    Initialize_Pixels ();

    // initialize pixel neighborhood structures
    Initialize_Neighbor_Structure ();

    // allocate and initialize the Cpix vector (length L)
    tiny = 1e-12;
    tinyf = REAL (tiny);
    hCpix = gsl_vector_alloc (L);
    gsl_vector_set_all (hCpix, tiny);
    gsl_blas_dgemv (CblasNoTrans,1.0,hC,hpixels,1.0,hCpix);

    // pre-compute the additive constant of objective function
    objaddconst = 0.0;
    for (int i=0; i<L; i++)
        objaddconst += gsl_sf_lngamma (hy->data[i]+1);

}

PET::~PET(void) {

    gsl_matrix_free (hC);
    gsl_vector_free (hy);
    gsl_vector_free (hpixels);
    gsl_vector_free (hCpix);
    gsl_vector_free (hPixNbSums);

    delete [] hPixNbCts;
    delete [] hPixNbPtrs;
    delete [] hPixNbStartIdx;

}

#define OPT_BLOCK_L		16
#define OPT_BLOCK_P		16

int PET::make_multiple_of (const int x, const int multiple) {
    int y = x;
    int remainder = y % multiple;
    if (remainder != 0) {
        y += multiple - remainder;
    }
    return y;
}

void PET::padded_dimensions (const int in_L, const int in_P,
                             int* out_L, int* out_P) {
    *out_L = make_multiple_of (in_L, OPT_BLOCK_L);
    *out_P = make_multiple_of (in_P, OPT_BLOCK_P);
}

void PET::SetAlgoParams (double chgTol, int maxIters,
                         int nSecants, int iGpuDeviceNumber) {
    chgtol = chgTol;
    maxiter = maxIters;
    nsecant = nSecants;
    niters = -1;
    gpuDeviceNumber = iGpuDeviceNumber;
}

const char* PET::GetAlgo (void) {

    string rtnValue = "";
    if (algorithmFlags & CPU)
        rtnValue += " CPU";
    if (algorithmFlags & GPU)
        rtnValue += " GPU";
    return rtnValue.c_str ();
    // TODO Return CPU/GPU info as well

}

void PET::OutputImage (void) {

    ostringstream penstr(ostringstream::out);
    penstr << penalty;
    if (algorithmFlags & CPU)
        imgfile = "./CPU";
    else if (algorithmFlags & GPU)
        imgfile = "./GPU";
    imgfile += "-penalty-";
    imgfile += penstr.str ();
    imgfile += ".img";
    cout << imgfile << endl;
    ofstream outFile (imgfile.c_str (), ios::out);
    if (!outFile) {
        cerr << "Datafile " << imgfile.c_str () << " write failed!\n\n";
        exit (1);
    }
    for (int i=0; i<imgNrows; i++) {
        for (int j=0; j<imgNcols; j++)
            outFile << gsl_vector_get (hpixels,i*imgNcols+j) << " ";
        outFile << endl;
    }
    outFile.close ();

}

void PET::Initialize_Pixels (void) {
    hpixels = gsl_vector_alloc (P);
    gsl_vector_set_all (hpixels, 1.0);
}

void PET::Initialize_Neighbor_Structure(void) {

    // initialize hPixNbCtsNew
    hPixNbCts = new int[P];
    // four corners
    hPixNbCts[0] = 3;
    hPixNbCts[imgNcols-1] = 3;
    hPixNbCts[(imgNrows-1)*imgNcols] = 3;
    hPixNbCts[imgNrows*imgNcols-1] = 3;
    // top row pixels
    for (int j=1; j<imgNcols-1; j++)
        hPixNbCts[j] = 5;
    // bottom row pixels
    for (int j=(imgNrows-1)*imgNcols+1; j<imgNrows*imgNcols-1; j++)
        hPixNbCts[j] = 5;
    // left column pixels
    for (int j=imgNcols; j<=(imgNrows-2)*imgNcols; j+=imgNcols)
        hPixNbCts[j] = 5;
    // right column pixels
    for (int j=2*imgNcols-1; j<(imgNrows-1)*imgNcols; j+=imgNcols)
        hPixNbCts[j] = 5;
    // interior pixels
    for (int i=1; i<imgNrows-1; i++)
        for (int j=1; j<imgNcols-1; j++)
            hPixNbCts[i*imgNcols+j] = 8;

    // initialize hPixNbStartIdxNew
    hPixNbStartIdx = new int[P+1];
    hPixNbStartIdx[0] = 0;
    for (int j=1; j<P+1; j++)
        hPixNbStartIdx[j] = hPixNbStartIdx[j-1] + hPixNbCts[j-1];

    // initialize hPixNbPtrsNew
    hPixNbPtrs = new int[hPixNbStartIdx[P]];
    // four corners
    hPixNbPtrs[hPixNbStartIdx[0]] = 1;
    hPixNbPtrs[hPixNbStartIdx[0]+1] = imgNcols;
    hPixNbPtrs[hPixNbStartIdx[0]+2] = imgNcols+1;
    hPixNbPtrs[hPixNbStartIdx[imgNcols-1]] = imgNcols-2;
    hPixNbPtrs[hPixNbStartIdx[imgNcols-1]+1] = 2*imgNcols-2;
    hPixNbPtrs[hPixNbStartIdx[imgNcols-1]+2] = 2*imgNcols-1;
    hPixNbPtrs[hPixNbStartIdx[(imgNrows-1)*imgNcols]] = (imgNrows-2)*imgNcols;
    hPixNbPtrs[hPixNbStartIdx[(imgNrows-1)*imgNcols]+1] = (imgNrows-2)*imgNcols+1;
    hPixNbPtrs[hPixNbStartIdx[(imgNrows-1)*imgNcols]+2] = (imgNrows-1)*imgNcols+1;
    hPixNbPtrs[hPixNbStartIdx[imgNrows*imgNcols-1]] = (imgNrows-1)*imgNcols-2;
    hPixNbPtrs[hPixNbStartIdx[imgNrows*imgNcols-1]+1] = (imgNrows-1)*imgNcols-1;
    hPixNbPtrs[hPixNbStartIdx[imgNrows*imgNcols-1]+2] = imgNrows*imgNcols-2;
    // top row pixels
    for (int j=1; j<imgNcols-1; j++) {
        hPixNbPtrs[hPixNbStartIdx[j]] = j-1;
        hPixNbPtrs[hPixNbStartIdx[j]+1] = j+1;
        hPixNbPtrs[hPixNbStartIdx[j]+2] = j+imgNcols-1;
        hPixNbPtrs[hPixNbStartIdx[j]+3] = j+imgNcols;
        hPixNbPtrs[hPixNbStartIdx[j]+4] = j+imgNcols+1;
    }  // bottom row pixels
    for (int j=(imgNrows-1)*imgNcols+1; j<imgNrows*imgNcols-1; j++) {
        hPixNbPtrs[hPixNbStartIdx[j]] = j-imgNcols-1;
        hPixNbPtrs[hPixNbStartIdx[j]+1] = j-imgNcols;
        hPixNbPtrs[hPixNbStartIdx[j]+2] = j-imgNcols+1;
        hPixNbPtrs[hPixNbStartIdx[j]+3] = j-1;
        hPixNbPtrs[hPixNbStartIdx[j]+4] = j+1;
    }
    // left column pixels
    for (int j=imgNcols; j<=(imgNrows-2)*imgNcols; j+=imgNcols) {
        hPixNbPtrs[hPixNbStartIdx[j]] = j-imgNcols;
        hPixNbPtrs[hPixNbStartIdx[j]+1] = j-imgNcols+1;
        hPixNbPtrs[hPixNbStartIdx[j]+2] = j+1;
        hPixNbPtrs[hPixNbStartIdx[j]+3] = j+imgNcols;
        hPixNbPtrs[hPixNbStartIdx[j]+4] = j+imgNcols+1;
    }
    // right column pixels
    for (int j=2*imgNcols-1; j<(imgNrows-1)*imgNcols; j+=imgNcols) {
        hPixNbPtrs[hPixNbStartIdx[j]] = j-imgNcols-1;
        hPixNbPtrs[hPixNbStartIdx[j]+1] = j-imgNcols;
        hPixNbPtrs[hPixNbStartIdx[j]+2] = j-1;
        hPixNbPtrs[hPixNbStartIdx[j]+3] = j+imgNcols-1;
        hPixNbPtrs[hPixNbStartIdx[j]+4] = j+imgNcols;
    }
    // interior pixels
    for (int i=1; i<imgNrows-1; i++)
        for (int j=1; j<imgNcols-1; j++) {
            hPixNbPtrs[hPixNbStartIdx[i*imgNcols+j]] = (i-1)*imgNcols+j-1;
            hPixNbPtrs[hPixNbStartIdx[i*imgNcols+j]+1] = (i-1)*imgNcols+j;
            hPixNbPtrs[hPixNbStartIdx[i*imgNcols+j]+2] = (i-1)*imgNcols+j+1;
            hPixNbPtrs[hPixNbStartIdx[i*imgNcols+j]+3] = i*imgNcols+j-1;
            hPixNbPtrs[hPixNbStartIdx[i*imgNcols+j]+4] = i*imgNcols+j+1;
            hPixNbPtrs[hPixNbStartIdx[i*imgNcols+j]+5] = (i+1)*imgNcols+j-1;
            hPixNbPtrs[hPixNbStartIdx[i*imgNcols+j]+6] = (i+1)*imgNcols+j;
            hPixNbPtrs[hPixNbStartIdx[i*imgNcols+j]+7] = (i+1)*imgNcols+j+1;
        }

    // allocate memory and update hPixNbSums (length P)
    hPixNbSums = gsl_vector_calloc (P);
    update_PixNbSums_cpu (hpixels->data, hPixNbSums->data);

}

void PET::scale_C (gsl_matrix* C) {
    double l1nrm;
    gsl_vector_view Ccol;
    for (int j=0; j<P; j++) {
        Ccol = gsl_matrix_column (C,j);
        l1nrm = gsl_blas_dasum (&Ccol.vector);
        gsl_vector_scale (&Ccol.vector, 1.0/l1nrm);
    }
}

void PET::SolvePET (double pen, long algo) {
    penalty = pen;
    algorithmFlags = algo;

    if (algorithmFlags & CPU)
        Setup_cpu (pen, algo);
    else
        Setup_cublas (pen, algo);

    //	clock_t init;
    struct timeval time1, time2;
    gettimeofday (&time1, NULL);

//  time_t start_t, end_t;
//  time(&start_t);
    if (algorithmFlags & CPU)
        SolvePET_cpu ();
    else if (algorithmFlags & GPU)
        SolvePET_cublas ();

    gettimeofday(&time2, NULL);
    double sec1 = time2.tv_sec - time1.tv_sec +
                  (double)(time2.tv_usec - time1.tv_usec) / 1000000.0;


    //time(&end_t);
//  algoTiming = difftime(end_t,start_t);
    algoTiming = sec1;

    if (algorithmFlags & CPU)
        Clean_cpu ();
    else
        Clean_cublas ();
}

int PET::Setup_cpu (double penalty, long algo) {

    // allocate memory
    hZ = gsl_matrix_alloc (L,P);

    // calculate initial objective value
    obj = objfn_cpu (hpixels->data,hCpix->data,hPixNbSums->data);
    cout << "\nInitial Objective Value:\n" << setw(10) << obj << endl << endl;
}

double PET::objfn_cpu (const double* pixels, const double* Cpix,
                       const double* PixNbSums) {
    double objval = 0.0;
    for (int i=0; i<L; i++)
        objval += (hy->data[i] * log(Cpix[i]) - Cpix[i]);
    objval -= objaddconst;
    if ( penalty==0 ) {
        return objval;
    } else {
        double objpen = 0.0;
        for (int j=0; j<P; j++)
            objpen += pixels[j] * ( double(hPixNbCts[j]) * pixels[j] - PixNbSums[j] );
        return objval-penalty*objpen/2.0;
    }
}

void PET::update_pixels_cpu (void) {

    // update the Z matrix
    gsl_matrix_set_zero (hZ);
    for (int i=0; i<L; i++)
        cblas_daxpy (P, hy->data[i]/hCpix->data[i], hC->data+i*P, 1, hZ->data+i*P, 1);

    // update the pixels
    if (penalty==0) {
        for (int j=0; j<P; j++)
            hpixels->data[j] *= cblas_dasum (L, hZ->data+j, P);;
    } else {
        double a,b,c;
        for (int j=0; j<P; j++) {
            a = -2.0*penalty*double(hPixNbCts[j]);
            b = penalty*(double(hPixNbCts[j])*hpixels->data[j]+hPixNbSums->data[j])-1;
            c = hpixels->data[j] * cblas_dasum (L, hZ->data+j, P);
            hpixels->data[j] = -0.5*(b+sqrt(b*b-4*a*c))/a;
        }
    }

    // update the hCpix vector (length L)
    gsl_vector_set_all (hCpix, tiny);
    gsl_blas_dgemv (CblasNoTrans,1.0,hC,hpixels,1.0,hCpix);

    // update the hPixNbSums vector (length L)
    if (penalty>0)
        update_PixNbSums_cpu (hpixels->data, hPixNbSums->data);

}

void PET::update_pixels_cpu (double* pixdiff, int stride) {
    // Overloading function: calculate finite diff simultaneously;
    // used for quasi-Newton acceleration

    // update the Z matrix
    gsl_matrix_set_zero (hZ);
    for (int i=0; i<L; i++)
        cblas_daxpy (P, hy->data[i]/hCpix->data[i], hC->data+i*P, 1, hZ->data+i*P, 1);

    // update the pixels and pixdiff
    double pixold;
    if (penalty==0) {
        for (int j=0; j<P; j++) {
            pixold = hpixels->data[j];
            hpixels->data[j] *= cblas_dasum (L, hZ->data+j, P);
            *(pixdiff+j*stride) = hpixels->data[j] - pixold;
        }
    } else {
        double a,b,c;
        for (int j=0; j<P; j++) {
            pixold = hpixels->data[j];
            a = -2.0*penalty*double(hPixNbCts[j]);
            b = penalty*(double(hPixNbCts[j])*hpixels->data[j]+hPixNbSums->data[j])-1;
            c = hpixels->data[j] * cblas_dasum (L, hZ->data+j, P);
            hpixels->data[j] = -(b+sqrt(b*b-4*a*c))/a/2.0;
            if (hpixels->data[j] < 0) hpixels->data[j] = 0.0;
            *(pixdiff+j*stride) = hpixels->data[j] - pixold;
        }
    }

    // update the hCpix vector (length L)
    gsl_vector_set_all (hCpix, tiny);
    gsl_blas_dgemv (CblasNoTrans,1.0,hC,hpixels,1.0,hCpix);

    // update the hPixNbSums vector (length L)
    if (penalty>0)
        update_PixNbSums_cpu (hpixels->data, hPixNbSums->data);

}


void PET::update_PixNbSums_cpu (const double* pixels, double* PixNbSums)
{
    int end;
    for (int j=0; j<P; j++) {
        end = hPixNbStartIdx[j+1];
        PixNbSums[j] = 0.0;
        for (int k=hPixNbStartIdx[j]; k<end; k++)
            PixNbSums[j] += pixels[hPixNbPtrs[k]];
    }
}

void PET::SolvePET_cpu (void) {

    // main loop
    if ( nsecant==0 ) {
        for (int iter=0; iter<maxiter; iter++)
        {
            update_pixels_cpu ();
            objold = obj;
            obj = objfn_cpu (hpixels->data,hCpix->data,hPixNbSums->data);

            cout.precision(10);
            if (iter%100==0) {
                cout << "Iter " << iter << endl;
                cout << "obj " << setw(12) << obj << endl;
            }
            if ( obj<objold ) {
                cerr << "!!! Non-increasing iterates !!!\n\n";
                exit(1);
            }
            if ( fabs(obj-objold)<chgtol*(fabs(objold)+1) )
            {
                niters = iter;
                break;
            }
        }
    } else { // quasi-Newton acceleration

        // allocate memory for temp variables
        double obj_MM,obj_QN;
        int secantOld,secantNew,hqnsignum=1;
        gsl_matrix* hqnU = gsl_matrix_alloc (P, nsecant);
        gsl_matrix* hqnV = gsl_matrix_alloc (P, nsecant);
        gsl_matrix* hqnUminusV = gsl_matrix_alloc (P, nsecant);
        gsl_matrix* hqnC = gsl_matrix_alloc (nsecant, nsecant);
        gsl_matrix* hqnCLU = gsl_matrix_alloc (nsecant, nsecant);
        gsl_vector* hqnPix0 = gsl_vector_alloc (P);
        gsl_vector* hqnPixQN = gsl_vector_alloc (P);
        gsl_vector* hqnPixDiff = gsl_vector_alloc (P);
        gsl_vector* hqnCrhs = gsl_vector_alloc (nsecant);
        gsl_vector* hqnCpix = gsl_vector_alloc (L);
        gsl_vector* hqnPixNbSums = gsl_vector_alloc (P);
        gsl_permutation* hqnPerm = gsl_permutation_alloc (nsecant);
        gsl_vector_view hqnUcol;

        // update hpixels, calculate finite diff, and store to U(:,0)
        update_pixels_cpu (hqnU->data, nsecant);

        // accumulate the first nsecant secant pairs
        // and fill out U and V
        for (int j=1; j<nsecant; j++) {
            // update hpixels, store finite diff to U(:,j) and V(:,j-1)
            update_pixels_cpu (hqnU->data+j, nsecant);
            cblas_dcopy (P, hqnU->data+j, nsecant, hqnV->data+j-1, nsecant);
        }

        // store current hpixels to hqnPixQN
        gsl_vector_memcpy (hqnPixQN, hpixels);

        // update pixels, calculate finite diff, and store to V(:,nescant)
        update_pixels_cpu (hqnV->data+nsecant-1, nsecant);
        obj_MM = objfn_cpu (hpixels->data,hCpix->data,hPixNbSums->data);

        // initialize indices for oldest/newest secant pair
        secantOld = 0;
        secantNew = nsecant-1;

        // calculate C = U^t(U-V)
        gsl_matrix_memcpy (hqnUminusV, hqnU);
        gsl_matrix_sub (hqnUminusV, hqnV);
        gsl_blas_dgemm (CblasTrans,CblasNoTrans,1.0,hqnU,hqnUminusV,0.0,hqnC);

        // main loops
        for (int iter=0; iter<maxiter; iter++) {

            // calculate hqnPixQN
            hqnUcol = gsl_matrix_column (hqnU, secantNew);
            gsl_blas_dgemv (CblasTrans,1.0,hqnU,&hqnUcol.vector,0.0,hqnCrhs);
            gsl_matrix_memcpy (hqnCLU, hqnC);
            gsl_linalg_LU_decomp (hqnCLU,hqnPerm,&hqnsignum);
            gsl_linalg_LU_svx (hqnCLU, hqnPerm, hqnCrhs);
            // gsl_vector_memcpy (hqnPixQN, hqnPix0);
            gsl_blas_dgemv (CblasNoTrans, 1.0, hqnV, hqnCrhs, 1.0, hqnPixQN);

            // project hqnPixQN to feasible region
            for (int j=0; j<P; j++)
                if ( hqnPixQN->data[j]<0 )
                    hqnPixQN->data[j] = (hpixels->data[j])/2.0;

            // calculate hqnCpix vector from hqnPixQN
            gsl_vector_set_all (hqnCpix, tiny);
            gsl_blas_dgemv (CblasNoTrans,1.0,hC,hqnPixQN,1.0,hqnCpix);

            // calculate hqnPixNbSums from hqnPixQN
            update_PixNbSums_cpu (hqnPixQN->data, hqnPixNbSums->data);

            // calculate objective value from QN
            obj_QN = objfn_cpu (hqnPixQN->data,hqnCpix->data,hqnPixNbSums->data);

            // decide jump or not
            // cout << "obj_QN = " << obj_QN << "  obj_MM = " << obj_MM << endl;
            if ( obj_QN>obj_MM ) { // jump!
                gsl_vector_memcpy (hpixels, hqnPixQN);
                gsl_vector_memcpy (hCpix, hqnCpix);
                gsl_vector_memcpy (hPixNbSums, hqnPixNbSums);
                obj = obj_QN;
            } else { // not jump
                obj = obj_MM;
            }

            cout.precision(10);
            // calculate and store finite diff to U(:,secantOld)
            update_pixels_cpu (hqnU->data+secantOld, nsecant);
            obj_MM = objfn_cpu (hpixels->data,hCpix->data,hPixNbSums->data);

            // display progress
            if (iter%100 == 0) {
                cout << "Iter " << iter << endl;
                cout << "obj " << obj_MM << endl;
            }

            // check stopping criterion
            // cout << "obj_MM = " << obj_MM << endl;
            if ( (obj_MM-obj)<chgtol*(abs(obj)+1) ) {
                niters = iter;
                obj = obj_MM;
                gsl_matrix_free (hqnU);
                gsl_matrix_free (hqnV);
                gsl_matrix_free (hqnUminusV);
                gsl_matrix_free (hqnC);
                gsl_matrix_free (hqnCLU);
                gsl_vector_free (hqnPix0);
                gsl_vector_free (hqnPixQN);
                gsl_vector_free (hqnPixDiff);
                gsl_vector_free (hqnCrhs);
                gsl_vector_free (hqnCpix);
                gsl_vector_free (hqnPixNbSums);
                gsl_permutation_free (hqnPerm);
                break;
            }

            // store current hpixels to hqnPixQN
            gsl_vector_memcpy (hqnPixQN, hpixels);

            // do one more MM update of V,W and
            // store diff to V(:,secantOld)
            update_pixels_cpu (hqnV->data+secantOld, nsecant);
            obj_MM = objfn_cpu (hpixels->data,hCpix->data,hPixNbSums->data);

            // update C
            gsl_vector_memcpy (&gsl_matrix_column(hqnUminusV,secantOld).vector,
                               &gsl_matrix_column(hqnU,secantOld).vector);
            gsl_vector_sub (&gsl_matrix_column(hqnUminusV,secantOld).vector,
                            &gsl_matrix_column(hqnV,secantOld).vector);
            gsl_blas_dgemv (CblasTrans, 1.0, hqnUminusV,
                            &gsl_matrix_column(hqnU,secantOld).vector,
                            0.0, &gsl_matrix_row(hqnC,secantOld).vector);
            gsl_blas_dgemv (CblasTrans, 1.0, hqnU,
                            &gsl_matrix_column(hqnUminusV,secantOld).vector,
                            0.0, &gsl_matrix_column(hqnC,secantOld).vector);

            // update indices
            secantNew = secantOld;
            secantOld = (secantOld+1)%nsecant;
        }
    }

    // display warning for maximum iterations
    if ( niters<0 ) {
        niters = maxiter;
        cout << "Maximum iterations " << maxiter << " achieved.\n";
    }

} // SolvePET_cpu()

void PET::Clean_cpu () {

    // free memory for intermedia arrays
    gsl_matrix_free (hZ);

}

double PET::objfn_gpu (const REAL* pixels, const REAL* Cpix,
                       const REAL* PixNbSums) {
    double objval;
    // evaluate obj value by lines
    evaluate_obj_lines_fh (dy, Cpix, dobjlines, L);
    objval = (double) cublasREALdot (L, donefL, 1, dobjlines, 1);
    objval -= objaddconst;
    if ( penalty==0 ) {
        return objval;
    } else {
        evaluate_obj_pixels_fh (pixels, dPixNbCts, PixNbSums, dobjpixs, P);
        objval -= penalty * double(cublasREALdot(P, donefP, 1, dobjpixs, 1)) / 2.0;
        return objval;
    }
}

void PET::update_pixels_gpu (void) {
    // update the Z matrix
//  cublasScopy (sizeC, dC, 1, dZ, 1);  // MAS: Moved this in update_pixels
    // update the pixels dpixels

    // MAS: I am removing code-duplication in update_pixels
//  if ( penalty==0 ) {
//    update_pixels_nopenalty_gpu_fh (dy, dCpix, dZ, dpixels, L, P);
//  }  else {
//    update_pixels_penalty_gpu_fh (dy, dCpix, dZ, dPixNbCts, dPixNbSums, dpixels, penalty, L, P);
//  }
    update_pixels_penalty_gpu_fh (dy, dCpix, dC, dZ, dZColSums, dPixNbCts,
                                  dPixNbSums, dpixels, penalty, L, P);

    // update the dCpix vector (length L)
    cublasREALgemv ('n',L,P,REAL(1.0),dC,L,dpixels,1,REAL(0.0),dCpix,1);
    cublasREALaxpy (L,tinyf,donefL,1,dCpix,1);

    // update the dPixNbSums vector (length L)
    if (penalty>0)
        update_NbSums_gpu_fh (dPixNbStartIdx, dPixNbPtrs, dpixels, dPixNbSums, np_P);
}

int PET::Setup_cublas (double pen, long algo) {

    // padding
    np_L = L;
    np_P = P;
    padded_dimensions (np_L,np_P,&L,&P); // (L,P) are now padded
    printf ("Dimensions before padding: %d x %d \n", np_L, np_P);
    printf ("            after padding: %d x %d \n", L, P);
    sizeC = L*P;
    np_sizeC = np_L*np_P;

    // initial objective value in CPU
    obj = objfn_cpu (hpixels->data,hCpix->data,hPixNbSums->data);
    cout << "\nInitial Objective Value in CPU:\n" << obj << endl;

    // initialize CUBLAS
    cudaSetDevice (gpuDeviceNumber);
    cout << "\nInitialize CUBLAS ...\n";
    cublasStatus status;
    status = cublasInit ();
    if (status != CUBLAS_STATUS_SUCCESS) {
        cerr << "!!!! CUBLAS initialization error\n";
        return EXIT_FAILURE;
    }

    // allocate device memory
    cout << "Allocate and transfer data to device memory ... \n";
    cublasAlloc (sizeC, sizeof(REAL), (void**)&dC);
    cublasAlloc (sizeC, sizeof(REAL), (void**)&dZ);
    cublasAlloc (L, sizeof(REAL), (void**)&dy);
    cublasAlloc (L, sizeof(REAL), (void**)&dCpix);
    cublasAlloc (L, sizeof(REAL), (void**)&dobjlines);
    cublasAlloc (L, sizeof(REAL), (void**)&donefL);
    cublasAlloc (P, sizeof(REAL), (void**)&dobjpixs);
    cublasAlloc (P, sizeof(REAL), (void**)&dpixels);
    cublasAlloc (P, sizeof(REAL), (void**)&donefP);
    cublasAlloc (P, sizeof(REAL), (void**)&dZColSums);
    cublasAlloc (hPixNbStartIdx[np_P], sizeof(int), (void**)&dPixNbPtrs);
    cublasAlloc (P, sizeof(int), (void**)&dPixNbCts);
    cublasAlloc (P+1, sizeof(int), (void**)&dPixNbStartIdx);
    cublasAlloc (P, sizeof(REAL), (void**)&dPixNbSums);

    // copy host hC (row-major), hy, hpixels, hPixNbCts, hPixNbSums to
    // device dC (column-major, REAL), dy, dpixels, dPixNbCts, dPixNbsums;
    honefL = gsl_vector_REAL_alloc (L);
    honefP = gsl_vector_REAL_alloc (P);
    hCtf = gsl_matrix_REAL_calloc (P, L);
    hyf = gsl_vector_REAL_calloc (L);
    hCpixf = gsl_vector_REAL_alloc (L);
    hpixelsf = gsl_vector_REAL_calloc (P);
    hPixNbSumsf = gsl_vector_REAL_calloc (P);
    hPixNbCtsPadded = new int[P];

    gsl_vector_REAL_set_all (honefL, REAL(1.0));
    gsl_vector_REAL_set_all (honefP, REAL(1.0));
    gsl_vector_REAL_set_all (hCpixf, tinyf);
    for (int i=0; i<np_L; i++) {
        hyf->data[i] = REAL(hy->data[i]);
        hCpixf->data[i] = REAL(hCpix->data[i]);
    }
    for (int j=0; j<np_P; j++) {
        hpixelsf->data[j] = REAL(hpixels->data[j]);
        hPixNbSumsf->data[j] = REAL(hPixNbSums->data[j]);
        hPixNbCtsPadded[j] = hPixNbCts[j];
        for (int i=0; i<np_L; i++ ) {
            gsl_matrix_REAL_set (hCtf,j,i,REAL(gsl_matrix_get(hC,i,j)));
        }
    }
    for (int j=np_P; j<P; j++)
        hPixNbCtsPadded[j] = 1;

    // transfer data from host to device
    cublasSetVector (sizeC, sizeof(REAL), hCtf->data, 1, dC, 1);
    cublasSetVector (L, sizeof(REAL), hyf->data, 1, dy, 1);
    cublasSetVector (L, sizeof(REAL), honefL->data, 1, donefL, 1);
    cublasSetVector (L, sizeof(REAL), hCpixf->data, 1, dCpix, 1);
    cublasSetVector (P, sizeof(REAL), hpixelsf->data, 1, dpixels, 1);
    cublasSetVector (P, sizeof(REAL), hPixNbSumsf->data, 1, dPixNbSums, 1);
    cublasSetVector (P, sizeof(REAL), honefP->data, 1, donefP, 1);
    cublasSetVector (P+1, sizeof(int), hPixNbStartIdx, 1, dPixNbStartIdx, 1);
    cublasSetVector (P, sizeof(int), hPixNbCtsPadded, 1, dPixNbCts, 1);
    cublasSetVector (hPixNbStartIdx[np_P], sizeof(int), hPixNbPtrs, 1, dPixNbPtrs, 1);

    // obtain objective value in GPU
    obj = objfn_gpu(dpixels, dCpix, dPixNbSums);
    cout.precision(10);
    cout << "\nInitial objective value in GPU:\n" << setw(10) << obj << endl << endl;
}

int PET::SolvePET_cublas (void) {

    // main loop
    if ( nsecant==0) {
        for (int iter=0; iter<maxiter; iter++) {

            // update pixels and then objective value
            update_pixels_gpu ();
            objold = obj;
            obj = objfn_gpu (dpixels, dCpix, dPixNbSums);

            // display progress
//       if ( obj<objold )
// 	cout << "!!! Non-increasing iterate !!! \n\n";
            if (iter%100==0) {
                cout << "Iter " << iter << endl;
                cout << "obj = " << obj << endl;
            }
            if ( abs(obj-objold)<chgtol*(abs(objold)+1) ) {
                niters = iter;
                break;
            }
        }
    } else { // quasi-Newton acceleration
//    // allocate memory for auxillary variables
//    int sizeVandW=sizeV+sizeW;
//    int secantOld, secantNew, hqnsignum=1;
//    double obj_MM,obj_QN;
//    REAL *dVptr,*dWptr;
//    REAL *dqnU,*dqnV,*dqnUminusV;
//    REAL *dqnC,*dqnCrhs;
//    REAL hqnC[nsecant][nsecant],hqnCrhsFloat[nsecant];
//    gsl_matrix *hqnCLU = gsl_matrix_alloc (nsecant,nsecant);
//    gsl_vector *hqnCrhs = gsl_vector_alloc (nsecant);
//    gsl_permutation *hqnPerm = gsl_permutation_alloc (nsecant);
//    REAL *dVWvec0,*dVWvecDiff,*dVWvecQN;
//    cublasAlloc (sizeVandW*nsecant, sizeof(REAL), (void**)&dqnU);
//    cublasAlloc (sizeVandW*nsecant, sizeof(REAL), (void**)&dqnV);
//    cublasAlloc (sizeVandW*nsecant, sizeof(REAL), (void**)&dqnUminusV);
//    cublasAlloc (sizeVandW, sizeof(REAL), (void**)&dVWvec0);
//    cublasAlloc (sizeVandW, sizeof(REAL), (void**)&dVWvecDiff);
//    cublasAlloc (sizeVandW, sizeof(REAL), (void**)&dVWvecQN);
//    cublasAlloc (nsecant*nsecant, sizeof(REAL), (void**)&dqnC);
//    cublasAlloc (nsecant, sizeof(REAL), (void**)&dqnCrhs);
//    // copy current V,W to VWvec0
//    cublasScopy (sizeV, dV, 1, dVWvec0, 1);
//    cublasScopy (sizeW, dW, 1, dVWvec0+sizeV, 1);
//    // update V,W and calculate finite difference
//    update_VW_gpu();
//    cublasScopy (sizeV, dV, 1, dqnU, 1);
//    cublasScopy (sizeW, dW, 1, dqnU+sizeV, 1);
//    cublasSaxpy (sizeVandW, -1.0f, dVWvec0, 1, dqnU, 1);
//    // udpate VWvec0
//    cublasScopy (sizeV, dV, 1, dVWvec0, 1);
//    cublasScopy (sizeW, dW, 1, dVWvec0+sizeV, 1);
//    // accumulate the first nsecant secant pairs
//    // and store them in U and V
//    for (int j=1; j<nsecant; j++) {
//      // update V,W and calculate finite diff
//      // and store the diff in U and V
//      update_VW_gpu();
//      cublasScopy (sizeV, dV, 1, dqnU+j*sizeVandW, 1);
//      cublasScopy (sizeW, dW, 1, dqnU+j*sizeVandW+sizeV, 1);
//      cublasSaxpy (sizeVandW, -1.0f, dVWvec0, 1, dqnU+j*sizeVandW, 1);
//      cublasScopy (sizeVandW, dqnU+j*sizeVandW, 1, dqnV+(j-1)*sizeVandW, 1);
//      // udpate VWvec0
//      cublasScopy (sizeV, dV, 1, dVWvec0, 1);
//      cublasScopy (sizeW, dW, 1, dVWvec0+sizeV, 1);
//    }
//    // update V,W and update the last column of V
//    update_VW_gpu();
//    obj_MM = objfn_gpu();
//    cout << "obj_MM = " << obj_MM << endl;
//    cublasScopy (sizeV, dV, 1, dqnV+(nsecant-1)*sizeVandW, 1);
//    cublasScopy (sizeW, dW, 1, dqnV+(nsecant-1)*sizeVandW+sizeV, 1);
//    cublasSaxpy (sizeVandW, -1.0f, dVWvec0, 1, dqnV+(nsecant-1)*sizeVandW, 1);
//    // initialize ptrs to oldest/newest secant pair
//    secantOld = 0;
//    secantNew = nsecant-1;
//    // calculate C=U^T(U-V)
//    cublasScopy (sizeVandW*nsecant, dqnU, 1, dqnUminusV, 1);
//    cublasSaxpy (sizeVandW*nsecant, -1.0f, dqnV, 1, dqnUminusV, 1);
//    cublasSgemm ('t','n',nsecant,nsecant,sizeVandW,1.0f,dqnU,sizeVandW,
//		 dqnUminusV,sizeVandW,0.0f,dqnC,nsecant);
//    for (int iter=0; iter<maxiter; iter++) {
//      // cout << "Iter " << iter << endl;
//      // calculate VWvecQN
//      cublasSgemv ('t',sizeVandW,nsecant,1.0f,dqnU,sizeVandW,
//		   dqnU+secantNew*sizeVandW,1,0.0f,dqnCrhs,1);
//      // copy Crhs,C to host, solve C x = Crhs,
//      // and copy results x back to dqnCrhs
//      cublasGetMatrix (nsecant, nsecant, sizeof(REAL), dqnC, nsecant, hqnC, nsecant);
//      cublasGetVector (nsecant, sizeof(REAL), dqnCrhs, 1, hqnCrhsFloat, 1);
//      for (int i=0; i<nsecant; i++) {
//	gsl_vector_set (hqnCrhs,i,double(hqnCrhsFloat[i]));
//	for (int j=0; j<nsecant; j++)
//	  gsl_matrix_set (hqnCLU,j,i,double(hqnC[i][j]));
//      }
//      gsl_linalg_LU_decomp (hqnCLU,hqnPerm,&hqnsignum);
//      gsl_linalg_LU_svx (hqnCLU,hqnPerm,hqnCrhs);
//      for (int i=0; i<nsecant; i++)
//	hqnCrhsFloat[i] = REAL(hqnCrhs->data[i]);
//      cublasSetVector (nsecant, sizeof(REAL), hqnCrhsFloat, 1, dqnCrhs, 1);
//      // finish calculation of dVWvecQN
//      cublasScopy (sizeVandW, dVWvec0, 1, dVWvecQN, 1);
//      cublasSgemv ('n',sizeVandW,nsecant,1.0f,dqnV,sizeVandW,dqnCrhs,1,1.0f,dVWvecQN,1);
//      // project VWvecQN to feasible region
//      project_VW_gpu_fh (dVWvecQN, dV, dW, sizeV, sizeW);
//      // calculate objective value from QN
//      dVptr = dV;
//      dWptr = dW;
//      dV = dVWvecQN;
//      dW = dVWvecQN+sizeV;
//      obj_QN = objfn_gpu();
//      dV = dVptr;
//      dW = dWptr;
//      // decide jump or not
//      //      cout << "obj_QN = " << obj_QN << "  obj_MM = " << obj_MM << endl;
//      if ( obj_QN<obj_MM ) { // jump!
//	cublasScopy (sizeVandW, dVWvecQN, 1, dVWvec0, 1);
//	cublasScopy (sizeV, dVWvecQN, 1, dV, 1);
//	cublasScopy (sizeW, dVWvecQN+sizeV, 1, dW, 1);
//	obj = obj_QN;
//      } else {
//	cublasScopy (sizeV, dV, 1, dVWvec0, 1);
//	cublasScopy (sizeW, dW, 1, dVWvec0+sizeV, 1);
//	obj = obj_MM;
//      }
//      // do one MM update of V,W
//      update_VW_gpu();
//      obj_MM = objfn_gpu();
//      // check stopping criterion
//      if ( (obj-obj_MM)<chgtol*(obj+1) ) {
//	niters = iter;
//	obj = obj_MM;
//	cublasFree (dqnU);
//	cublasFree (dqnV);
//	cublasFree (dqnUminusV);
//	cublasFree (dVWvec0);
//	cublasFree (dVWvecDiff);
//	cublasFree (dVWvecQN);
//	cublasFree (dqnCrhs);
//	cublasFree (dqnC);
//	gsl_matrix_free (hqnCLU);
//	gsl_vector_free (hqnCrhs);
//	gsl_permutation_free (hqnPerm);
//	break;
//      }
//      // calculate finite diff and update U
//      cublasScopy (sizeV, dV, 1, dqnU+secantOld*sizeVandW, 1);
//      cublasScopy (sizeW, dW, 1, dqnU+secantOld*sizeVandW+sizeV, 1);
//      cublasSaxpy (sizeVandW, -1.0f, dVWvec0, 1, dqnU+secantOld*sizeVandW, 1);
//      // update VWvec0
//      cublasScopy (sizeV, dV, 1, dVWvec0, 1);
//      cublasScopy (sizeW, dW, 1, dVWvec0+sizeV, 1);
//      // do one more MM update of V,W and update V
//      update_VW_gpu();
//      obj_MM = objfn_gpu();
//      cublasScopy (sizeV, dV, 1, dqnV+secantOld*sizeVandW, 1);
//      cublasScopy (sizeW, dW, 1, dqnV+secantOld*sizeVandW+sizeV, 1);
//      cublasSaxpy (sizeVandW, -1.0f, dVWvec0, 1, dqnV+secantOld*sizeVandW, 1);
//      // update C
//      cublasScopy (sizeVandW, dqnU+secantOld*sizeVandW, 1,
//		   dqnUminusV+secantOld*sizeVandW, 1);
//      cublasSaxpy (sizeVandW, -1.0f, dqnV+secantOld*sizeVandW, 1,
//		   dqnUminusV+secantOld*sizeVandW, 1);
//      cublasSgemv ('t',sizeVandW,nsecant,1.0f,dqnUminusV,sizeVandW,
//		   dqnU+secantOld*sizeVandW,1,0.0f,dqnC+secantOld,sizeVandW);
//      cublasSgemv ('t',sizeVandW,nsecant,1.0f,dqnU,sizeVandW,
//		   dqnUminusV+secantOld*sizeVandW,1,0.0f,dqnC+secantOld*sizeVandW,1);
//      // udpate ptrs to oldest/newest secant pair
//      secantNew = secantOld;
//      secantOld = (secantOld+1)%nsecant;
//    }
    }

    if ( niters<0 ) {
        niters = maxiter;
        cout << "\nMaximum iterations " << maxiter << " achieved.\n";
    }

    // copy dpixels back to host
    cout << "\nTransfer results to host ...\n";
    cublasGetVector (P, sizeof(REAL), dpixels, 1, hpixelsf->data, 1);

    // single -> double precision
    for (int j=0; j<np_P; j++)
        hpixels->data[j] = double(hpixelsf->data[j]);

    // update hCpix
    gsl_vector_set_all (hCpix, tiny);
    gsl_blas_dgemv (CblasNoTrans, 1.0, hC, hpixels, 1.0, hCpix);

    // update hPixNbSums
    update_PixNbSums_cpu (hpixels->data, hPixNbSums->data);

    // recalculate the final objective value in CPU
    obj = objfn_cpu (hpixels->data, hCpix->data, hPixNbSums->data);
} // SolvePET_cublas()

void PET::Clean_cublas() {

    // memory clean up
    cout << "Free device memory ... \n";
    cublasFree (dC);
    cublasFree (dZ);
    cublasFree (dy);
    cublasFree (dpixels);
    cublasFree (dCpix);
    cublasFree (dobjlines);
    cublasFree (dobjpixs);
    cublasFree (donefL);
    cublasFree (donefP);
    cublasFree (dZColSums);
    cublasFree (dPixNbPtrs);
    cublasFree (dPixNbCts);
    cublasFree (dPixNbStartIdx);
    cublasFree (dPixNbSums);
    cublasShutdown();

    gsl_vector_REAL_free (honefL);
    gsl_vector_REAL_free (honefP);
    gsl_matrix_REAL_free (hCtf);
    gsl_vector_REAL_free (hyf);
    gsl_vector_REAL_free (hpixelsf);
    gsl_vector_REAL_free (hPixNbSumsf);
    gsl_vector_REAL_free (hCpixf);

    delete [] hPixNbCtsPadded;

} // Clean_cublas()

void PET::print_gpu_matrix (REAL* M, int nrows, int ncols,
                            int dispnrows, int dispncols) {
// this function is for debugging purpose

    // assume M is colomn-major, single
    int size = nrows*ncols;
    REAL* hM = new REAL[size];
    cublasGetMatrix (nrows, ncols, sizeof(REAL), M, nrows, hM, nrows);
    for (int i=0; i<dispnrows; i++) {
        for (int j=0; j<dispncols; j++)
            //       if ( (i!=j) && (hM[i+j*nrows]==0) )
            // cout << "(" << i << "," << j << "):" << hM[i+j*nrows] << endl;
            cout << hM[i+j*nrows] << " ";
        cout << endl;
    }
    delete [] hM;
}

void PET::print_cpu_matrix(double* M, int nrows, int ncols,
                           int dispnrows, int dispncols) {
    // this function is for debugging purpose
    // assume M is row-major, double
    for (int i=0; i<dispnrows; i++) {
        for (int j=0; j<dispncols; j++)
            cout << M[i*ncols+j] << " ";
        cout << endl;
    }
}
