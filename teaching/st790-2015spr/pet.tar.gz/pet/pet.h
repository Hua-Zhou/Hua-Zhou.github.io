#ifndef PET_H
#define PET_H

#define CUDA

#include <gsl/gsl_blas.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_sf_gamma.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <ctime>
#include <cmath>

#include "precision.h"


#ifdef CUDA
	#include "cuda.h"
    #include "cublas.h"
//	#include "GPU/GPUInterface.h"
//	#include "GPU/KernelLauncherMM.h"
#endif // CUDA

using namespace std;

enum AlgorithmType {
    CPU = 1 << 10,
    GPU = 1 << 11
};

// declaration, forward
extern "C" void 
evaluate_obj_lines_fh (const REAL *, const REAL *, REAL *, int);

extern "C" void
evaluate_obj_pixels_fh (const REAL *, const int*, const REAL *, REAL *, int);

extern "C" void
update_pixels_nopenalty_gpu_fh (const REAL *, const REAL *, REAL *, REAL *, int, int);

extern "C" void
update_pixels_penalty_gpu_fh (const REAL *, const REAL *, const REAL *, REAL *, 
			      REAL *, const int*, const REAL *, REAL *, double, int, int);

extern "C" void
update_NbSums_gpu_fh (const int*, const int*, const REAL *, REAL *, int);

// PET class declaration
class PET
{
 public:
  PET (const char*, const char*);
  ~PET(void);
  void SolvePET (double, long);
  void OutputImage (void);
  double GetAlgoTiming(void) { return algoTiming; }
  double GetChgtol (void) { return chgtol; }
  double GetObjval (void) { return obj; }
  double * GetPixels (void) { return hpixels->data; }
  int GetNiters (void) { return niters; }
  int GetNpixels (void) { return np_P; }
  int GetNlines (void) { return np_L; }
  double GetPenalty (void) { return penalty;}
  void SetAlgoParams (double,int,int,int);
  const char* GetAlgo (void);

 private:
  long algorithmFlags;
  // scalars
  int L,P,sizeC;
  int np_L,np_P,np_sizeC;
  int imgNrows, imgNcols;
  int maxiter,niters,nsecant;
  REAL tinyf;
  double algoTiming,chgtol,penalty,tiny;
  double obj,objaddconst,objold;
  string imgfile;
  // host memory pointers
  gsl_matrix *hC,*hZ;
  gsl_vector *hCpix,*hpixels,*hPixNbSums,*hy;
  int *hPixNbPtrs,*hPixNbCts,*hPixNbCtsPadded,*hPixNbStartIdx;
  gsl_vector_REAL *hyf,*hpixelsf,*hPixNbSumsf,*hCpixf;
  gsl_matrix_REAL *hCtf;
  // device memory pointers
  gsl_vector_REAL *honefL,*honefP;
  REAL *donefL,*donefP;
  REAL *dC,*dy,*dZ;
  REAL *dpixels,*dCpix,*dPixNbSums,*dZColSums;
  REAL *dobjlines,*dobjpixs;
  int *dPixNbStartIdx,*dPixNbCts,*dPixNbPtrs;
  
  int gpuDeviceNumber;

  // functions 
  void Initialize_Neighbor_Structure (void);
  void Initialize_Pixels (void);
  double objfn_cpu (const double*, const double*, const double*);
  double objfn_gpu (const REAL*, const REAL*, const REAL*);
  void scale_C (gsl_matrix*);
  int SolvePET_cublas (void);
  void SolvePET_cpu (void);
  void update_pixels_cpu (void);
  void update_pixels_cpu (double*, int);
  void update_PixNbSums_cpu (const double*, double*);
  void update_pixels_gpu (void);
  int Setup_cpu(double, long);
  int Setup_cublas(double, long);
  void Clean_cpu (void);
  void Clean_cublas (void);
  // for debugging purpose
  void print_gpu_matrix (REAL*, int, int, int, int);
  void print_cpu_matrix (double*, int, int, int, int);
  // for optimization
  int make_multiple_of (const int, const int);
  void padded_dimensions (const int, const int, int*, int*);

// #ifdef CUDA
//   GPUInterface* gpu;
//   KernelLauncherMM* kernels;
// #endif // CUDA

};

#endif
