/*
 * precision.h
 *
 *  Created on: Jul 19, 2010
 *      Author: msuchard
 */

#define DOUBLE_PRECISION

#ifndef PRECISION_H_
#define PRECISION_H_

#ifndef DOUBLE_PRECISION

#define	REAL	float
#define gsl_vector_REAL					gsl_vector_float
#define gsl_matrix_REAL					gsl_matrix_float

#define gsl_vector_REAL_free(x)			gsl_vector_float_free(x)
#define gsl_matrix_REAL_free(x)			gsl_matrix_float_free(x)
#define gsl_matrix_REAL_set(x,y,z,w)	gsl_matrix_float_set(x,y,z,w)
#define gsl_vector_REAL_set_all(x,y)	gsl_vector_float_set_all(x,y)
#define gsl_vector_REAL_calloc(x)		gsl_vector_float_calloc(x)
#define gsl_matrix_REAL_calloc(x,y)		gsl_matrix_float_calloc(x,y)
#define gsl_vector_REAL_alloc(x)		gsl_vector_float_alloc(x)

#define cublasREALgemv(a,b,c,d,e,f,g,h,i,j,k)	cublasSgemv(a,b,c,d,e,f,g,h,i,j,k)
#define cublasREALaxpy(a,b,c,d,e,f)				cublasSaxpy(a,b,c,d,e,f)
#define cublasREALdot(a,b,c,d,e)				cublasSdot(a,b,c,d,e)

#else // DOUBLE_PRECISION

#define REAL	double
#define gsl_vector_REAL					gsl_vector
#define gsl_matrix_REAL					gsl_matrix

#define gsl_vector_REAL_free(x)			gsl_vector_free(x)
#define gsl_matrix_REAL_free(x)			gsl_matrix_free(x)
#define gsl_matrix_REAL_set(x,y,z,w)	gsl_matrix_set(x,y,z,w)
#define gsl_vector_REAL_set_all(x,y)	gsl_vector_set_all(x,y)
#define gsl_vector_REAL_calloc(x)		gsl_vector_calloc(x)
#define gsl_matrix_REAL_calloc(x,y)		gsl_matrix_calloc(x,y)
#define gsl_vector_REAL_alloc(x)		gsl_vector_alloc(x)

#define cublasREALgemv(a,b,c,d,e,f,g,h,i,j,k)	cublasDgemv(a,b,c,d,e,f,g,h,i,j,k)
#define cublasREALaxpy(a,b,c,d,e,f)				cublasDaxpy(a,b,c,d,e,f)
#define cublasREALdot(a,b,c,d,e)				cublasDdot(a,b,c,d,e)

#endif

#endif /* PRECISION_H_ */
