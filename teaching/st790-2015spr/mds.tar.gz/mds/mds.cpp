#ifndef MDS_CPP_
#define MDS_CPP_

#include "mds.h"

MDS::MDS (const char* infile) {

    // read in data matrix: N-by-(S+1)
    ifstream inFile;
    cout << "\nRead in data: " << infile << endl;
    inFile.open(infile);
    if (!inFile) {
        cerr << "Datafile " << infile << " open failed!\n\n";
        exit(1);
    }
    // first line contains: N (# individuals), S (# SNPs)
    inFile >> N;
    inFile >> S;
    hGenotypeInt = new int[N*S];
    hPhenotypeInt = new int[N];
    hPredictInt = new int[S*(S-1)/2];
    // read in phenotype/genotype data
    int elem;
    for (int i=0; i<N; i++) {
        inFile >> elem;
        // case: 1, control: -1
        hPhenotypeInt[i] = (elem==1)? 1:-1;
        for (int j=0; j<S; j++) {
            inFile >> elem;
            hGenotypeInt[i*S+j] = elem;
        }
    }
    inFile.close ();
}

MDS::~MDS (void) {
    delete [] hGenotypeInt;
    delete [] hPhenotypeInt;
    delete [] hPredictInt;
}

void MDS::SetAlgoParams (int iGpuDeviceNumber, long algo) {
	algorithmFlags = algo;
	if (algorithmFlags & CPU) {
		cout << "CPU is being used\n\n";
		return;
	}
	struct cudaDeviceProp gpuDeviceProp;
    cudaGetDeviceCount (&numGPUDevices);
    gpuDeviceNumber = iGpuDeviceNumber;
    if (gpuDeviceNumber > numGPUDevices-1) {
        cerr << "GPU device " << gpuDeviceNumber << " not found\n";
        cerr << "Max GPU device number = " << numGPUDevices-1 << endl;
        cerr << endl;
        exit (1);
    }
    cudaSetDevice (gpuDeviceNumber);
    cudaGetDeviceProperties (&gpuDeviceProp, gpuDeviceNumber);
    cout << "GPU device " << gpuDeviceNumber << " is being used:\n";
    cout << gpuDeviceProp.name << endl << endl;
}

const char* MDS::GetAlgo (void) {
    string rtnValue = "";
    if (algorithmFlags & CPU)
        rtnValue += "CPU";
    if (algorithmFlags & GPU)
        rtnValue += "GPU";
    return rtnValue.c_str ();
    // TODO Return CPU/GPU info as well
}

void MDS::SolveMDS (long algo) {
    algorithmFlags = algo;
    //	start timing
    time_t start_t, end_t;
    time (&start_t);
    // run algorithm
    if (algorithmFlags & CPU)
        SolveMDS_CPU();
    else
        SolveMDS_CUDA();
    // stop timing
    time(&end_t);
    algoTiming = difftime(end_t,start_t);
}

void MDS::Setup_CUDA (void) {
    // allocate vectors/arrays in device memory
    cout << "Allocate device memory ... \n";
    cudaMalloc ((void**)&dGenotypeInt, N*S*sizeof(int));
    cudaMalloc ((void**)&dPhenotypeInt, N*sizeof(int));
    cudaMalloc ((void**)&dPredictInt, (S/2)*sizeof(int));

    // transfer data to device
    cout << "Transfer data to device memory ... \n";
    cudaMemcpy (dGenotypeInt, hGenotypeInt, N*S*sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy (dPhenotypeInt, hPhenotypeInt, N*sizeof(int), cudaMemcpyHostToDevice);
}

void MDS::Cleanup_CUDA (void) {
    // free vectors/arrays in device memory
    cout << "Free device memory ... \n";
    if (dGenotypeInt) cudaFree (dGenotypeInt);
    if (dPhenotypeInt) cudaFree (dPhenotypeInt);
    if (dPredictInt) cudaFree (dPredictInt);
}

void MDS::SolveMDS_CUDA (void) {
    // initialize
    Setup_CUDA ();
    // (S-1) sweeps to classify genotypes
    for (int round=0; round<S-1; round++) {
        // cout << "round " << round << endl;
        if (round%((S-1)/10)==0) cout << 10*(round/((S-1)/10)) << "%\n";
        MDS_kernel_fh (round, N, S, dGenotypeInt, dPhenotypeInt, dPredictInt);
        cudaMemcpy (hPredictInt+round*(S/2), dPredictInt, 
        			S/2*sizeof(int), cudaMemcpyDeviceToHost);
    }
    // clean up
    Cleanup_CUDA ();
}

void MDS::SolveMDS_CPU (void) {
    int snp1, snp2, idx=0;
    int* classifyInt = new int[9];
    int* gidx = new int[N];
    int* genotypeRowIdx;
    for (int r=0; r<S-1; r++) {
        if (r%((S-1)/10)==0) cout << 10*(r/((S-1)/10)) << "%\n";
        for (int pidx=0; pidx<S/2; pidx++) {
            snp1 = ((pidx-r)>=0)? (pidx-r):(S-1+pidx-r);
            snp2 = ((S-r-2-pidx)>=0)? (S-r-2-pidx):(2*S-pidx-r-3);
            if (pidx==(S/2-1)) snp2=S-1;
            for (int i=0; i<9; i++) classifyInt[i]=0;
            for (int i=0; i<N; i++) {
                genotypeRowIdx = hGenotypeInt+i*S;
                gidx[i] = 3*(*(genotypeRowIdx+snp1))+(*(genotypeRowIdx+snp2));
                classifyInt[gidx[i]] += hPhenotypeInt[i];
            }
            for (int i=0; i<9; i++)
                classifyInt[i] = (classifyInt[i]>=0)? 1:-1;
            hPredictInt[idx] = 0;
            for (int i=0; i<N; i++) {
                hPredictInt[idx] += (classifyInt[gidx[i]]==hPhenotypeInt[i]);
            }
            idx++;
        }
    }
    delete [] classifyInt;
    delete [] gidx;
}

void MDS::Print_Result(const char* outfile) {
    // read in data matrix: N-by-(S+1)
    ofstream outFile;
    cout << "\nOutput to file: " << outfile << endl;
    outFile.open (outfile);
    if (!outFile) {
        cerr << "Output file " << outfile << " open failed!\n\n";
        exit(1);
    }
    // output format: snp1 snp2 predictCt
    int snp1, snp2;
    int* idx=hPredictInt;
    /*for (int r=0; r<S-1; r++) {*/
    for (int r=0; r<1; r++) {
        for (int pidx=0; pidx<S/2; pidx++) {
            snp1 = (pidx-r)>=0? (pidx-r):(S-1+pidx-r);
            snp2 = (S-r-2-pidx)>=0? (S-r-2-pidx):(2*S-pidx-r-3);
            if (pidx==S/2-1) snp2=S-1;
            outFile << snp1 << "\t" << snp2 << "\t" << *idx << endl;
            idx++;
        }
    }
    outFile.close();
}

void MDS::print_gpu_matrix_int (int* dM, int nrows, int ncols,
                                int dispnrows, int dispncols)
{
    // this function is for debugging purpose
    // assume M is row-major, int
    int size = nrows*ncols;
    int* hM = new int[size];
    cudaMemcpy (hM, dM, size*sizeof(int), cudaMemcpyDeviceToHost);
    for (int i=0; i<dispnrows; i++) {
        for (int j=0; j<dispncols; j++)
            cout << hM[i*ncols+j] << " ";
        cout << endl;
    }
    delete [] hM;
}

void MDS::print_cpu_matrix_int (int* M, int nrows, int ncols,
                                int dispnrows, int dispncols)
{
    // this function is for debugging purpose
    // assume M is row-major, int
    for (int i=0; i<dispnrows; i++) {
        for (int j=0; j<dispncols; j++)
            cout << M[i*ncols+j] << " ";
        cout << endl;
    }
}

#endif //MDS_CPP_
