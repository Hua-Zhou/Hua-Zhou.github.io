#ifndef MDS_H
#define MDS_H

#include <cuda.h>
#include <cuda_runtime_api.h>

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <ctime>

enum AlgorithmType {
    CPU = 1 << 10,
    GPU = 1 << 11
};

using namespace std;

// declaration, forward
extern "C" void
MDS_kernel_fh (const int r, const int N, const int S,
               int* genotypeInt, int* phenotypeInt,
               int* predictInt);

// MDS class declaration
class MDS
{
public:
    MDS (const char*);
    ~MDS (void);
    void Cleanup_CUDA (void);
    double GetAlgoTiming (void) {
        return algoTiming;
    }
    const char* GetAlgo (void);
    int GetN (void) {
        return N;
    }
    int GetS(void) {
        return S;
    }
    void Print_Result (const char*);
    void print_gpu_matrix_int (int*, int, int, int, int);
    void print_cpu_matrix_int (int*, int, int, int, int);
    void SetAlgoParams (int, long);
    void Setup_CUDA (void);
    void SolveMDS (long);
    void SolveMDS_CPU (void);
    void SolveMDS_CUDA (void);

private:
    double algoTiming;
    int gpuDeviceNumber,numGPUDevices,N,S;
    int *dGenotypeInt, *dPhenotypeInt, *dPredictInt;
    int *hGenotypeInt, *hPhenotypeInt, *hPredictInt;
    long algorithmFlags;
};

#endif
