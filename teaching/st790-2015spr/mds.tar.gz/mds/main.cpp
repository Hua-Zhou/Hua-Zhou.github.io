#include <iostream>
#include <string>
#include <iomanip>
#include <stdlib.h>

using namespace std;

#include "mds.h"

void abort(std::string msg) {
    std::cerr << msg << "\nAborting..." << std::endl;
    exit (1);
}

void helpMessage() {
    std::cerr << "Usage:\n\n";
    std::cerr << "mds [--help] [--datafile <string>] [--GPU <integer>]\n\n";
    std::cerr << "If --help is specified, this usage message is shown\n\n";
    std::cerr << "If --datafile is specified, the file containing phenotype/genotype matrix \n";
    std::cerr << "   should be given\"\n";
    std::cerr << "   Default: ./gaw17.txt\n\n";
    std::cerr << "If --GPU is specified, estimation proceeds on the GPU with given device number\n";
    std::cerr << "   Default: no GPU used \n\n";
    std::cerr << "Example usages: \n\n";
    std::cerr << "./mds --help\n";
    std::cerr << "./mds --datafile ./gaw17.txt --GPU 0 \n";
    exit (0);
}

void interpretCommandLineParameters (int argc, const char* argv[], string* fileName,
                                     int* gpuDeviceNumber, long* flags)
{
    bool expecting_fileName = false;
    bool expecting_gpuDeviceNumber = false;
    *fileName = "./gaw17.txt";
    *flags = 0;
    *gpuDeviceNumber = 0;

    for (int i = 1; i < argc; ++i) {
        std::string option = argv[i];
        if (expecting_fileName) {
            *fileName = option.c_str ();
            expecting_fileName = false;
        } else if (expecting_gpuDeviceNumber) {
            *gpuDeviceNumber = (unsigned) atoi (option.c_str());
            *flags |= GPU;
            expecting_gpuDeviceNumber = false;
        } else if (option == "--help") {
            helpMessage();
        } else if (option == "--datafile") {
            expecting_fileName = true;
        } else if (option == "--GPU") {
            expecting_gpuDeviceNumber = true;
        } else {
            std::string msg("Unknown command line parameter \"");
            msg.append (option);
            abort (msg.c_str());
        }
    }

    if (expecting_fileName)
        abort("read last command line option without finding value associated with --datafile");
    if (expecting_gpuDeviceNumber)
        abort("read last command line option without finding value associated with --GPU");
    if ( (*flags & GPU) && (*gpuDeviceNumber < 0) )
        abort("invalid GPU device number supplied on the command line");
    if (!(*flags & GPU))
        *flags |= CPU;
}

int main(int argc, const char* argv[])
{
    int gpuDeviceNumber;
    long flags;
    string fileName;
    interpretCommandLineParameters (argc, argv, &fileName, &gpuDeviceNumber, &flags);
    string outName = fileName + ".out";

    // Read in data and perform MDS
    MDS mdstest (fileName.c_str());
    cout << "# individuals = " << mdstest.GetN() << endl;
    cout << "# SNPs = " << mdstest.GetS () << endl << endl;
    mdstest.SetAlgoParams (gpuDeviceNumber, flags);
    cout << "Perform MDS ... " << endl;
    mdstest.SolveMDS (flags);
    mdstest.Print_Result (outName.c_str());

    // Output timing results
    cout.precision (10);
    cout.setf (ios::left);
    cout << endl;
    cout << "Algorithm: \n" << mdstest.GetAlgo () << endl;
    cout << "Elapsed Time:" << endl;
    cout << setw (8) << mdstest.GetAlgoTiming () << endl << endl;

    return 0;
}
